M.O.S — PRESS PACK
October 2026

Contents
  MOS-press-kit.pdf        4-page press kit (bios, music, booking)
  /photos/web-1600         Photos, long edge ~1400-1600px (web, screens)
  /photos/social-1080      Photos, 1080px (stories, socials)
  /logos                   Wordmark in ink / paper / mono (SVG + PNG), icon
  /bios                    Copy-ready biographies (EN + FR) and fact sheet

Usage
  Photos and logos are for promotion of M.O.S events, releases and press.
  Credit: courtesy of the artist.
  Please do not recolour or distort the wordmark. Pink: #E04E8F. Ink: #171310. Paper: #F2EDE4.
  Higher-resolution exports and performance video on request.

Contact
  Management & booking: booking.mosmusic@gmail.com
  mosmusic.be — soundcloud.com/moskitoss — @m.o.s_music
